interface LinkedListInterface{
	public boolean addFirst(int value);
	public void removeFifthElement();
	public int lastEvenPosition();
}